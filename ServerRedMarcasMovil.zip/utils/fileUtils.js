const fs = require('fs');
const path = require('path');
const { PutObjectCommand } = require('@aws-sdk/client-s3');

// Asegurar que el directorio existe
function ensureDirSync(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

// Subir a S3 (si es necesario, en caso de producción)
const uploadToS3 = async (fileContent, fileName, documentFolder, s3Client) => {
  const params = {
    Bucket: process.env.BUCKET_NAME,
    Key: `${documentFolder}/${fileName}`,
    Body: fileContent,
    ContentType: 'image/jpeg', // Ajustado para imágenes
  };

  try {
    const command = new PutObjectCommand(params);
    await s3Client.send(command);
    const location = `https://${params.Bucket}.s3.${process.env.REGION}.amazonaws.com/${params.Key}`;
    return { Location: location };
  } catch (error) {
    console.error('Error al subir a S3:', error);
    throw error;
  }
};

// En desarrollo, construir la URL local con la IP específica
function getLocalFileUrl(fileName, folder) {
  const baseUrl = `http://192.168.1.47/files-redm/fotos_negocios/${folder}`;
  return `${baseUrl}/${fileName}`;
}

// Guardar la imagen localmente en el directorio de XAMPP
function saveImageLocally(base64Image, folder, fileName) {
  const xamppDirectory = path.join('C:/xampp/htdocs/files-redm/fotos_negocios', folder); // Ruta absoluta en XAMPP
  ensureDirSync(xamppDirectory); // Aseguramos que el directorio existe

  const filePath = path.join(xamppDirectory, fileName);
  const buffer = Buffer.from(base64Image, 'base64'); // Convertimos la imagen base64 a un buffer
  fs.writeFileSync(filePath, buffer); // Guardamos la imagen en el sistema de archivos

  // Retornamos la URL pública para acceder a la imagen
  return getLocalFileUrl(fileName, folder);
}

module.exports = {
  ensureDirSync,
  uploadToS3,
  saveImageLocally,
};
