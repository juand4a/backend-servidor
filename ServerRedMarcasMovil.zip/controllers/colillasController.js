// controllers/colillasController.js

const pdfParse = require('pdf-parse');
const { PDFDocument } = require('pdf-lib');
const fs = require('fs');
const path = require('path');
const { S3Client, PutObjectCommand, ListObjectsV2Command, GetObjectCommand } = require('@aws-sdk/client-s3');
const Colillas = require('../models/colillaspagocolaborador'); // Importar el modelo de colillas

// Configuración de AWS S3
const isProduction = process.env.NODE_ENV === 'production'; // Verifica si es producción

let s3Client;
if (isProduction) {
  s3Client = new S3Client({
    region: process.env.REGION,
    credentials: {
      accessKeyId: process.env.ACCESS_KEY,
      secretAccessKey: process.env.ACCESS_SECRET,
    },
  });
}

// Función para subir archivo a S3 en producción
const uploadToS3 = async (filePath, fileName, documentFolder) => {
  if (!isProduction) return null; // No sube a S3 si no es producción

  const fileContent = fs.readFileSync(filePath);
  const params = {
    Bucket: process.env.BUCKET_NAME,
    Key: `${documentFolder}/${fileName}`, // Guardar en la carpeta específica
    Body: fileContent,
    ContentType: 'application/pdf', // Ajusta según el tipo de archivo
  };

  try {
    const command = new PutObjectCommand(params);
    await s3Client.send(command);
    const location = `https://${params.Bucket}.s3.${process.env.REGION}.amazonaws.com/${params.Key}`;
    return { Location: location };
  } catch (error) {
    console.error('Error al subir a S3:', error);
    throw error;
  }
};

// Función para asegurar que el directorio existe localmente
function ensureDirSync(dirPath) {
  try {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  } catch (err) {
    console.error('Error al crear el directorio', err);
    throw err; // Re-lanzar el error para manejarlo en el controlador
  }
}

// Función para guardar las páginas del PDF sin ninguna validación
async function savePdfPagesWithoutValidation(base64Pdf, outputDirectory, fechaSubida) {
  try {
    // Decodificar el PDF de base64
    const pdfData = Buffer.from(base64Pdf, 'base64');

    // Cargar el documento PDF usando pdf-lib
    const pdfDoc = await PDFDocument.load(pdfData);

    // Obtener el número de páginas en el PDF
    const totalPages = pdfDoc.getPageCount();

    // Crear el directorio si no existe (solo en desarrollo)
    if (!isProduction) {
      ensureDirSync(outputDirectory);
      console.log(`Directorio creado: ${outputDirectory}`);
    }

    // Guardar cada página del PDF como un archivo separado
    for (let i = 0; i < totalPages; i++) {
      const newPdfDoc = await PDFDocument.create();
      const [copiedPage] = await newPdfDoc.copyPages(pdfDoc, [i]);
      newPdfDoc.addPage(copiedPage);

      const fileName = `colilla_page_${i + 1}.pdf`;
      const filePath = path.join(outputDirectory, fileName);
      const pdfBytes = await newPdfDoc.save();

      if (isProduction) {
        // Subir a S3 en producción
        const documentFolder = `colillas/${fechaSubida}`;
        await uploadToS3(filePath, fileName, documentFolder);
        console.log(`Página subida a S3: ${fileName}`);
      } else {
        // Guardar localmente en desarrollo
        fs.writeFileSync(filePath, pdfBytes);
        console.log(`Página guardada localmente: ${filePath}`);
      }
    }

    return totalPages;
  } catch (error) {
    console.error('Error al guardar las páginas del PDF:', error);
    throw error;
  }
}

// Función para procesar cada PDF ya separado y registrar en la base de datos
async function processSeparatedPdfsAndRegisterInDB(outputDirectory, fechaSubida) {
  try {
    let pdfFiles;

    if (isProduction) {
      // Obtener archivos de S3
      const command = new ListObjectsV2Command({
        Bucket: process.env.BUCKET_NAME,
        Prefix: `colillas/${fechaSubida}/`,
      });
      const data = await s3Client.send(command);
      pdfFiles = data.Contents.filter(file => file.Key.endsWith('.pdf'));
    } else {
      // Obtener archivos locales
      const files = fs.readdirSync(outputDirectory);
      pdfFiles = files.filter(file => file.endsWith('.pdf'));
    }

    // Crear la base URL para los archivos PDF
    const baseUrl = isProduction
      ? `https://${process.env.BUCKET_NAME}.s3.amazonaws.com/colillas/${fechaSubida}`
      : `http://192.168.1.47/files-redm/colillas/${fechaSubida}`;

    for (const pdfFile of pdfFiles) {
      const filePath = isProduction
        ? `${baseUrl}/${pdfFile.Key}`
        : path.join(outputDirectory, pdfFile);

      // Leer el archivo PDF y extraer el texto con pdf-parse
      const pdfData = isProduction
        ? (await s3Client.send(new GetObjectCommand({ Bucket: process.env.BUCKET_NAME, Key: pdfFile.Key }))).Body
        : fs.readFileSync(filePath);
      const parsedPdf = await pdfParse(pdfData);

      // Extraer el C.C. del texto del PDF
      const docid = extractID(parsedPdf.text);

      if (docid) {
        // Si encontramos el docid, construir la URL completa para el PDF
        const fileUrl = `${baseUrl}/${pdfFile.Key || pdfFile}`;

        // Registrar el archivo en la base de datos
        await Colillas.create({
          docid: docid,           // El C.C. extraído del PDF
          url: fileUrl,           // URL del archivo PDF
          fechaSubida: new Date(fechaSubida),  // Fecha de subida
          fechaPago: new Date(),  // Fecha de pago, puedes cambiarla según sea necesario
        });

        console.log(`Procesado el archivo ${pdfFile.Key || pdfFile} con docid ${docid}`);
      } else {
        console.warn(`No se encontró C.C. en el archivo ${pdfFile.Key || pdfFile}`);
      }
    }

    return `Se procesaron y registraron ${pdfFiles.length} archivos PDF correctamente.`;
  } catch (error) {
    console.error('Error al procesar los archivos PDF:', error);
    throw error;
  }
}

// Controlador para manejar el PDF y procesar sus páginas
exports.createColillasForAllColaboradores = async (req, res) => {
  const { pdfBase64, fechaSubida } = req.body;

  // Directorio donde se guardarán los archivos PDF separados (solo en desarrollo)
  const outputDirectory = path.join('C:/xampp/htdocs/files-redm/colillas', fechaSubida);

  try {
    // 1. Guardar las páginas del PDF sin ninguna validación
    await savePdfPagesWithoutValidation(pdfBase64, outputDirectory, fechaSubida);

    // 2. Procesar cada PDF guardado para extraer el docid y registrar en la base de datos
    await processSeparatedPdfsAndRegisterInDB(outputDirectory, fechaSubida);

    res.json({ message: 'Los archivos PDF se han procesado y registrado correctamente.' });
  } catch (error) {
    console.error('Error al procesar las colillas:', error);
    res.status(500).json({ error: 'Ocurrió un error al procesar los archivos PDF.' });
  }
};

// Controlador para obtener las colillas por `docid`
exports.getColillasByDocid = async (req, res) => {
  const { docid } = req.params; // Obtener el docid de los parámetros de la URL

  try {
    // Buscar todas las colillas que coincidan con el docid
    const colillas = await Colillas.findAll({
      where: { docid: docid }
    });

    // Verificar si hay resultados
    if (colillas.length > 0) {
      res.json(colillas); // Enviar los datos encontrados en formato JSON
    } else {
      res.status(404).json({ message: 'No se encontraron colillas para este docid.' });
    }
  } catch (error) {
    console.error('Error al obtener las colillas:', error);
    res.status(500).json({ error: 'Ocurrió un error al obtener las colillas.' });
  }
};
